import filecmp

file1path = file("./output/markov_cpp_out.txt")
file2path = file("./output/markov_java_out.txt")
file3path = file("./output/markov_cpp_out.txt")

if filecmp.cmp(file1path, file2path, shallow = True) and filecmp.cmp(file1path, file3path, shallow = True):
	print("Output is identical between C, C++, and Java versions of the Markov Chain Algorithm")	
else:
	print("Output discrepancy!")