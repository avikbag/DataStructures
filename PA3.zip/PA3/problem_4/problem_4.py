#!/usr/bin/python
import sys
import math

class SensorReading:
	def __init__(self,strLine):
#this is very repititous code may have been better to leave as a list
		self.initLine=strLine
		self.line = strLine.split()
		self.indice = self.line[0]
		self.date = self.line[1]
		self.time = self.line[2]
		self.wind = self.line[3]
		self.height = self.line[4]
		self.angle = self.line[5]
		self.latitude = self.line[6]
		self.longitude = self.line[7]
		self.temp = self.line[8]
		self.mach = self.line[9]	
		self.knots = self.line[10]	
		self.minAcc = self.line[11]
		self.maxAcc = self.line[12]
		self.weight = self.line[13]


	def printSensor(self):
		print(self.line)
	
	def sensorCheck(self,checkFile):

		for line in checkFile:
			if self.initLine==line:
				return True
		return False

class flight:

	def __init__(self,data):
		self.listofSensors=[]
		self.name = data

	def addData(self,data) :
		self.listofSensors.append(data)

	def avgHeight(self):
		total=0
		for index in range(len(self.listofSensors)):
			total=int(self.listofSensors[index].height)+total
		return total/len(self.listofSensors)
	
	def avgTemp(self):
		total=0
		for index in range(len(self.listofSensors)):
			total=int(self.listofSensors[index].temp)+total
		return total/len(self.listofSensors)
	
	def avgWind(self):
		total=0
		for index in range(len(self.listofSensors)):
			total=int(self.listofSensors[index].wind)+total
		return total/len(self.listofSensors)
	
	def stdDevHeight(self):
		total=0
		avg=self.avgHeight()	
		for index in range(len(self.listofSensors)):
			total=(float(self.listofSensors[index].height)-avg)**2+total
		return math.sqrt(total/len(self.listofSensors))
	
	def stdDevTemp(self):
		total=0
		avg=self.avgTemp()	
		for index in range(len(self.listofSensors)):
			total=(float(self.listofSensors[index].temp)-avg)**2+total
		return math.sqrt(total/len(self.listofSensors))
	
	def stdDevWind(self):
		total=0
		avg=self.avgWind()	
		for index in range(len(self.listofSensors)):
			total=(float(self.listofSensors[index].wind)-avg)**2+total
		return math.sqrt(total/len(self.listofSensors))
	
	def nameCheck(self,checkFile):
		# checks if flight name is in origin file
		for line in checkFile:
			if self.name==line:
				return True
		return False

	def SensorsTest(self,checkFile):
		# checks if the sensor data is in origin file
		for index in range(len(self.listofSensors)):
			if not self.listofSensors[index].sensorCheck(checkFile):
				return False			
		return True

	def printFlight(self):
		print "Flight %s" % (self.name)
		print "average height is %s + or - %s" % (self.avgHeight(),self.stdDevHeight())
		print "average Temp is %s + or - %s" %(self.avgTemp(),self.stdDevTemp())
		print "average wind is %s + or - %s" % (self.avgWind(),self.stdDevWind())
		print
if __name__=="__main__":
#open output file and change printing to output file
	outputFile=file('Output.txt','w')
	print "\n-------------------------------------- Question 4 --------------------------------------"
	print "----------------------------------------------------------------------------------------"
	print "-------------------------------------- Gads Test ---------------------------------------\n"
	filename=sys.argv[1]
	f=open(filename,'r')
	fcompare=open(filename,'r')
#intialize important variables not neccisary just cautious 
	gadsList=[]
	numFlights=0
# build data structure from file 
	for line in f:
# flightnames are Capital letters only so a digit a line[7] is sensor data
		if line[7].isdigit():
			x=SensorReading(line)
			if numFlights>=1:
				gadsList[numFlights-1].addData(x)
		else:
			newFlight= flight(line)
			gadsList.append(newFlight)
			numFlights= numFlights+1

#output to file check if data in data structure flight is in original file
	for index in range(len(gadsList)):
		if	gadsList[index].nameCheck(fcompare) and gadsList[index].SensorsTest(fcompare) :
			gadsList[index].printFlight()	
