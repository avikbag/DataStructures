## Question Number 3
## CSV Implementation on Python

# Libraries used
import os
import os.path

class CSV(object):

	def __init__(self, inputFile): ## Initializing Constructor
		self.inputFile  = inputFile
		self.data = file(inputFile,'r') # Access to files
		self.store = [] 

	def printRaw(self): ## Method to print out raw data from the input file by line
		(self.data).seek(0);
		print "\n------------------------------------ Raw Input Data ------------------------------------\n"
		for line in self.data:
			print line.rstrip('\n')


	def split(self): ## Parse the input data per line and store it into global _STORE[] variable
		res = []
		global store
		(self.data).seek(0);
		k = 0
		for line in self.data: # Access each line
			lineSplit = (line.rstrip('\n')).split(',') 	# Split each line by using ',' as delimiter
			j = 0;
			for i in range(0,len(lineSplit)):
				if (i+j) >= len(lineSplit): # To check if it's within range
					break
				if (lineSplit[i+j].count('"') % 2 == 0): # Checks if the (") character is balanced
					res.append(lineSplit[i+j].replace('"',''))
				else: 					# If the (") is not balanced, it means 
					fld = lineSplit[i+j]# there are more than one value in that data field
					TRUE = 1
					test = ''
					while TRUE == 1: 
						j+=1 # Manipulate the loop
						if ((lineSplit[i+j].count('"')) % 2 == 1): # To check for the next occurence of 
							test = test + lineSplit[i+j]       # unbalanced data field and break loop
							break;
						else:
							test = test + lineSplit[i+j] + ","
					final = fld + ',' + test 	# concatenate and clean up the words
					final = final.replace('"','')
					final = final.replace(',','","')
					final = '"' + final + '"'
					res.append(final) # Append into result string list
				fld = '' # reset fld
			(self.store).append(res[:]) # Append copy of res into global variable _STORE[]
			del res[:] # reset res list
			
	def output(self):
		print "\n------------------------------------ CSV Parsed Data -----------------------------------\n"
		for line in self.store:
			for w in line:
				print ("-> " + w),
			print("\n")
	def getWord(self, line, word):
		if (not self.store):
			print("The list is empty, run split() method to parse before accessing data elements")
		else: 
			return self.store[line][word]

	def getLine(self, line):
		if (not self.store):
			print("The list is empty, run split() method to parse before accessing data elements")
		else: 
			return self.store[line]

## Main part of the CSV parse code
print "\n-------------------------------------- Question 3 --------------------------------------"
print "----------------------------------------------------------------------------------------"
print "-------------------------------------- CSV Parser --------------------------------------\n"
fileInput =  raw_input("Enter the file name for analysis(must be a .txt file): ")
if (os.path.isfile(fileInput) == False):
	print "Invalid file name / using default file"
	fileInput = "testData.txt"
print ("Accessing file: " + fileInput)
# calling methods from CSV class
csv = CSV(fileInput) 	## Initialize class CSV with given file name
csv.printRaw() 		## Prints Raw data by the line
csv.split()		## Parses through the given data and stores it to _STORE[]
csv.output()		## Prints out final result
