import random;
import sys;

nonword = "\n"
word1 = nonword
word2 = nonword

infile = open('alice30.txt')

statetab = {}

testlistbuild = {}

# BUILD PHASE

infile.seek(0)
for line in infile:
	for inword in line.split():
		statetab.setdefault( (word1, word2), [] ).append(inword)
		testlistbuild.setdefault((word1, word2),0) # Fills testlist with all the prefixes generated
		testlistbuild[(word1, word2)] += 1
		word1 = word2
		word2 = inword

statetab.setdefault( (word1, word2), [] ).append(nonword)

# GENERATE PHASE

word1 = nonword
word2 = nonword
GEN_MAX = 10000
ctr = 0
print "\n-------------------------------------- Question 2 --------------------------------------"
print "----------------------------------------------------------------------------------------"
print "-------------------------- Markov Chain Implementation Testing -------------------------\n"
infile.seek(0)
for i in xrange(GEN_MAX):
	nword = random.choice(statetab[(word1, word2)])
	# print [word1, word2];
	if (word1, word2) in testlistbuild:
		ctr += 1

	if nword == nonword:
		print "                   Mismatch in the Build Phase and the Generate Phase\n"
		sys.exit()
	#print nword;
	word1, word2 = word2, nword
if (ctr == GEN_MAX):
	print "      The Prefixes occuring in the Build phase is matched in the Generate Phase\n"